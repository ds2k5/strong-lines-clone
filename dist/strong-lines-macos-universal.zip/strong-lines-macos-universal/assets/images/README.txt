Place your PNG or JPG images in this folder.

The game will load images from here to reveal as you play.

Recommended image size: 800x600 pixels

For now, create a file named "default.png" in this directory to use as the background image.

You can use any image editing tool to create or convert images:
- GIMP
- ImageMagick (convert command)
- Online converters

Example to create a test image with ImageMagick:
  convert -size 800x600 xc:blue default.png

Or use any of your favorite images!
